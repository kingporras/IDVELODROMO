

# 🏆 EL INTER DE VERDÚN — App de Gestión del Equipo (PWA)

## Resumen
App privada tipo móvil (PWA) para gestionar el equipo de fútbol 7 "El Inter de Verdún". Diseño premium con paleta celeste/blanco/dorado, autenticación por usuario/contraseña, roles ADMIN y JUGADOR, y todas las funcionalidades de gestión deportiva.

---

## 🎨 Identidad Visual
- **Fondo principal**: Azul celeste con marca de agua sutil "INTER DE VERDÚN" en patrón repetido
- **Tarjetas**: Blancas con bordes redondeados suaves
- **Acentos**: Dorado para botones, iconos destacados y detalles
- **Logo**: Escudo del club (que subirás) en login, header y pantalla Club
- **Tipografía**: Moderna y limpia
- **Navegación inferior**: Estilo app móvil con iconos (Inicio, Calendario, Convocatoria, Rendimiento, Club + Admin Panel solo para admin)

---

## 🔐 1. Autenticación y Usuarios
- Login con Supabase Auth usando email ficticio (ej: `porras@interdeverdun.app`) mapeado desde username
- Sin registro público — solo usuarios creados por el admin
- 15 jugadores precargados con username = apodo y password = dorsal
- `porras` (dorsal 4) como ADMIN/capitán
- Roles gestionados en tabla separada `user_roles` (seguridad contra escalación de privilegios)

## 📱 2. Pantalla de Login
- Escudo centrado, fondo celeste, diseño premium
- Campos: usuario y contraseña
- Redirección automática según rol tras login

## 🏠 3. Inicio (Jugador)
- Tarjeta "Próximo partido" con rival, fecha/hora y lugar
- Botones rápidos: **VOY / NO VOY / DUDA**
- Muestra estado actual del jugador para el próximo partido
- Aviso destacado si el estado es "Pendiente"

## 📅 4. Calendario
- Lista/agenda con los 16 partidos de la liga
- Cada partido muestra: fecha, hora, rival, local/visitante
- Al tocar un partido: detalle completo con lugar, botón **"Cómo llegar"** (abre Google Maps → Velòdrom d'Horta), notas y acceso a convocatoria/MVP

## 📋 5. Convocatoria (por partido)
- Estados por jugador: Pendiente / Voy / No voy / Duda
- Contadores en tiempo real (confirmados, dudas, bajas, pendientes)
- Cupo configurable (default 14, editable por admin)
- Lista de espera automática si se supera el cupo (últimos en confirmar)
- Cada jugador solo puede cambiar su propio estado

## 📊 6. Rendimiento
- Estadísticas del jugador: partidos asistidos, no asistidos, % asistencia
- Historial por partido con la respuesta dada

## ⭐ 7. MVP (por partido)
- Dentro del detalle de cada partido: sección "Votar MVP"
- Lista de jugadores para votar (1 voto por jugador por partido)
- Tras votar: UI bloqueada con confirmación
- Resultados visibles: totales y MVP destacado

## ⚽ 8. Alineación (solo ADMIN)
- Campo de fútbol 7 visual con formación **2-3-1 + portero**
- Selector para asignar jugador a cada posición
- Lista "Banco" con jugadores no asignados
- Jugadores solo pueden ver la alineación (no editar)

## 💰 9. Pagos (solo ADMIN)
- Pantalla privada con lista de jugadores
- Switch Pagado/Pendiente por jugador
- Fecha de pago y nota opcionales
- Invisible para jugadores

## 🏟️ 10. Club
- Escudo, nombre del club
- Enlace a Instagram @interdeverdunbcn
- Enlaces a la liga y perfil del equipo en apuntamelo.com
- Ubicación Velòdrom d'Horta con botón "Cómo llegar"

---

## 🔧 Acciones Admin (botones)

### A) Botón Lunes: "Abrir convocatoria + Enviar recordatorio"
- Encuentra el próximo partido, crea/resetea convocatoria, pone todos en "Pendiente"
- Envía email recordatorio a todos los jugadores vía Resend
- Control de duplicados con `last_sent_at` y opción de forzar reenvío

### B) Botón Pago: "Enviar email de pago 25€"
- Envía email a TODOS con instrucciones de pago
- Control de duplicados con `last_payment_email_sent_at`

---

## 📧 Emails (Resend)
- Edge functions en Supabase para envío de emails
- Necesitarás configurar tu `RESEND_API_KEY` como secreto
- Dos plantillas: recordatorio de convocatoria y aviso de pago

## 🗄️ Base de Datos (Supabase)
- Tablas: profiles, user_roles, matches, convocations, convocation_responses, attendance, mvp_votes, lineups, payments, app_settings
- RLS estricto: jugadores solo leen/escriben lo suyo; admin acceso total
- Seed inicial con los 16 partidos y 15 usuarios

## 📲 PWA
- Instalable desde el navegador en iOS/Android
- Navegación inferior tipo app nativa
- Responsive optimizado para móvil

